# Assignment 02 — Car Marketplace System (Extended OOP)
**FAST NUCES Karachi | Spring 2026 | OOP CS1004**

---

## File Structure

```
A2-[StudentID]/
├── IListable.h              # Abstract interface (header only)
├── ISearchable.h            # Abstract interface (header only)
├── IReportable.h            # Abstract interface (header only)
└── CarMarketplace_A2.cpp    # All classes + main in one file
```

**Compile & Run:**
```bash
g++ -std=c++17 CarMarketplace_A2.cpp -o marketplace
./marketplace
```

---

## 1. Inheritance — 6 Relationships

| Chain | Why |
|---|---|
| IListable <- Vehicle <- Car | Car is a Vehicle that can be listed; adds doors, airbags, safety rating, sunroof, infotainment |
| IListable <- Vehicle <- Bike | Bike adds bikeType, maxRPM, weight, cargoRack |
| IListable <- Vehicle <- Truck | Truck adds payload, axles, refrigeration, towingCapacity |
| IReportable <- User <- Seller | Seller is a User who sells; IReportable forces generateReport() and showDashboard() |
| IReportable <- User <- Buyer | Buyer is a User who buys; same interface enforced |
| IReportable <- User <- Admin | Admin is a User with elevated privileges |

---

## 2. Polymorphism

displayDetails() is pure virtual in Vehicle, overridden in Car, Bike, Truck.

Called through base pointer:
  Vehicle* polyDemo[] = {civic, cbr500, hino};
  polyDemo[i]->displayDetails();  // virtual dispatch

IReportable polymorphic dispatch:
  IReportable* reporters[] = {&ahmed, &sara, &superAdmin};
  reporters[i]->generateReport();

ISearchable polymorphic dispatch:
  ISearchable* searcher = &platform;
  searcher->searchByBrand("Toyota");

---

## 3. Abstraction — 3 Abstract Classes (IListable.h, ISearchable.h, IReportable.h)

IListable  — enforces displayDetails(), getListingSummary(), getPrice(), getListingID()
ISearchable — enforces searchByBrand(), searchByPriceRange(), searchByYear(), displayAllApproved()
IReportable — enforces generateReport(), showDashboard()

Header-only because pure abstract classes contain no implementation — all implementations
are in the concrete subclasses inside CarMarketplace_A2.cpp.

---

## 4. Operator Overloading

Vehicle:    == (same listingID), < (cheaper), > (more expensive), << (stream)
PriceRange: + (merge ranges), == (exact match), < (lower midpoint), > (higher midpoint), << (stream)
Seller:     == (same userID), + (combined revenue), << (stream)
Message:    == (same sender+receiver+timestamp), << (stream)
Buyer:      == (same userID), << (stream)

Key example - PriceRange + operator:
  PriceRange budget(500000, 1500000, "Budget");
  PriceRange mid(1500000, 3500000, "Mid");
  PriceRange merged = budget + mid;  // PKR 500000 - 3500000
  platform.searchByPriceRangeObj(merged);

---

## 5. Friend Functions

negotiateDeal(Buyer& buyer, Seller& seller, double askingPrice)
  - Friend of Buyer and Seller
  - Accesses Buyer::budget, Seller::sellerRating, Seller::totalRevenue privately
  - Justification: bilateral operation that needs private data from both sides simultaneously

generateAuditLog(Admin& admin, Marketplace& platform)
  - Friend of Admin and Marketplace
  - Accesses Admin action counts + Marketplace operational stats privately
  - Justification: compliance report that crosses both class boundaries

---

## 6. Integration with Assignment 01

A1 Vehicle made abstract, split into Car/Bike/Truck with displayDetails() override.
A1 User now also inherits IReportable.
A1 SearchEngine now implements ISearchable interface.
A1 Marketplace now implements ISearchable, uses heap Vehicle* for polymorphism.
A1 Message gains == and << operator overloads.
All A1 static members, composition, and aggregation relationships preserved.
